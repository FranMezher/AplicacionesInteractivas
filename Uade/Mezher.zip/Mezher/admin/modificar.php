  <div class="form-group">
    <label for="inputState" class="form-label">Categoria</label><br>
    <select class="form-select" name="categoria" required >
      <option selected>Elegir...</option>
      <?php
      $query = "SELECT * FROM autos";
      $resultado = mysqli_query($conn, $query);
      while ($row = mysqli_fetch_array($resultado)) { ?>
        <option value="<?php echo $row['id_auto'] ?>"><?php echo $row['categoria'] ?></option>
      <?php } ?>
    </select>
  </div>