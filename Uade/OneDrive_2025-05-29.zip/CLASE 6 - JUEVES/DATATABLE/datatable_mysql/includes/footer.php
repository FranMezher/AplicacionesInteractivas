<!-- cdn bootstrap js -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>


<!-- cdn jquery js -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- cdn datatable js -->

<script src="//cdn.datatables.net/2.1.7/js/dataTables.min.js"></script>


<script>
let table = new DataTable('#myTable');
</script>


</body>
</html>