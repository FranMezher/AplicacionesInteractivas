<?php 

date_default_timezone_set('america/argentina/buenos_aires');
$conexion=mysqli_connect("localhost","root","","final2");

?>