<!DOCTYPE html>
<html>
<head>
	<title>CLASE 6 - FORMULARIO</title>
	 <!-- cdn bootstrap css -->
	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- cdn datatable css -->

    <link rel="stylesheet" href="//cdn.datatables.net/2.1.7/css/dataTables.dataTables.min.css">
</head>
<body>
    
